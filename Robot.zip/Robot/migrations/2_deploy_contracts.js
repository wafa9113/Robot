const Robot = artifacts.require("Robot");
module.exports = function(deployer) {
     deployer.deploy(Robot);
} ;